import { Hono } from "hono";
import { cors } from "hono/cors";
import { getStore } from "@netlify/blobs";
import { randomBytes, randomUUID } from "node:crypto";
import { and, asc, eq, sql } from "drizzle-orm";
import { db } from "../../db/index.ts";
import { players, squads } from "../../db/schema.ts";

export const config = { path: "/api/*" };

const SQUAD_SIZE = 4;
const MAX_IMAGE_BYTES = 4 * 1024 * 1024;
const REGIONS = [
  "NA-West",
  "NA-Central",
  "NA-East",
  "Europe",
  "Brazil",
  "Asia",
  "Oceania",
  "Middle East",
];
const IMAGE_TYPES: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "image/gif": "gif",
};

const proofs = () => getStore({ name: "token-proofs", consistency: "strong" });

const app = new Hono();

// The page is also meant to be opened straight from a folder (file://),
// which sends Origin: null, so the API accepts requests from any origin.
app.use("/api/*", cors({ origin: "*", allowMethods: ["GET", "POST", "OPTIONS"] }));

const clean = (v: unknown, max: number) =>
  typeof v === "string" ? v.replace(/\s+/g, " ").trim().slice(0, max) : "";

const newCrewCode = () => {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = randomBytes(6);
  return Array.from(bytes, (b) => chars[b % chars.length]).join("");
};

async function checkCrew(id: number, code: unknown) {
  const [squad] = await db.select().from(squads).where(eq(squads.id, id));
  if (!squad) return { error: "That squad does not exist.", status: 404 as const };
  if (clean(code, 20).toUpperCase() !== squad.crewCode) {
    return { error: "Wrong crew code. Only squad members can update this squad.", status: 403 as const };
  }
  return { squad };
}

app.get("/api/squads", async (c) => {
  const allSquads = await db.select().from(squads).orderBy(asc(squads.id));
  const allPlayers = await db.select().from(players).orderBy(asc(players.id));
  const result = allSquads.map((s) => ({
    id: s.id,
    name: s.name,
    region: s.region,
    tokenFound: s.tokenFound,
    proofUrl: s.proofKey ? `/api/proof/${s.proofKey}` : null,
    foundAt: s.foundAt,
    createdAt: s.createdAt,
    members: allPlayers
      .filter((p) => p.squadId === s.id)
      .map((p) => ({ username: p.username, hasMic: p.hasMic })),
  }));
  return c.json({ squadSize: SQUAD_SIZE, squads: result });
});

app.post("/api/join", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const username = clean(body.username, 32);
  const region = clean(body.region, 30);
  const hasMic = body.hasMic === true;

  if (username.length < 3) return c.json({ error: "Type your Fortnite username (at least 3 characters)." }, 400);
  if (!REGIONS.includes(region)) return c.json({ error: "Pick the region you live in." }, 400);

  const usernameKey = username.toLowerCase();
  const [existing] = await db.select().from(players).where(eq(players.usernameKey, usernameKey));
  if (existing) return c.json({ error: `${username} is already in a squad.` }, 409);

  // Fill the oldest open squad in the same region first, otherwise start a new one.
  const [open] = await db
    .select({ id: squads.id, crewCode: squads.crewCode })
    .from(squads)
    .where(
      and(
        eq(squads.region, region),
        eq(squads.tokenFound, false),
        sql`(select count(*) from ${players} where ${players.squadId} = ${squads.id}) < ${SQUAD_SIZE}`,
      ),
    )
    .orderBy(asc(squads.id))
    .limit(1);

  const squad =
    open ??
    (await db.insert(squads).values({ region, crewCode: newCrewCode() }).returning({ id: squads.id, crewCode: squads.crewCode }))[0];

  try {
    await db.insert(players).values({ squadId: squad.id, username, usernameKey, region, hasMic });
  } catch {
    return c.json({ error: `${username} is already in a squad.` }, 409);
  }

  return c.json({ squadId: squad.id, crewCode: squad.crewCode }, 201);
});

app.post("/api/squads/:id/verify", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const check = await checkCrew(Number(c.req.param("id")), body.crewCode);
  if ("error" in check) return c.json({ error: check.error }, check.status);
  return c.json({ ok: true });
});

app.post("/api/squads/:id/name", async (c) => {
  const id = Number(c.req.param("id"));
  const body = await c.req.json().catch(() => ({}));
  const check = await checkCrew(id, body.crewCode);
  if ("error" in check) return c.json({ error: check.error }, check.status);

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(players)
    .where(eq(players.squadId, id));
  if (count < SQUAD_SIZE) {
    return c.json({ error: `Your squad can pick a name once all ${SQUAD_SIZE} hunters have joined.` }, 400);
  }

  const name = clean(body.name, 40);
  if (name.length < 2) return c.json({ error: "Team name must be at least 2 characters." }, 400);

  await db.update(squads).set({ name }).where(eq(squads.id, id));
  return c.json({ ok: true });
});

app.post("/api/squads/:id/found", async (c) => {
  const id = Number(c.req.param("id"));
  const form = await c.req.formData().catch(() => null);
  if (!form) return c.json({ error: "Could not read the upload." }, 400);

  const check = await checkCrew(id, form.get("crewCode"));
  if ("error" in check) return c.json({ error: check.error }, check.status);

  const file = form.get("screenshot");
  if (!(file instanceof File) || file.size === 0) {
    return c.json({ error: "Add a picture of your screen showing the token." }, 400);
  }
  const ext = IMAGE_TYPES[file.type];
  if (!ext) return c.json({ error: "The picture must be a PNG, JPG, WEBP or GIF." }, 400);
  if (file.size > MAX_IMAGE_BYTES) return c.json({ error: "That picture is too big (4 MB max)." }, 400);

  const key = `squad-${id}-${randomUUID()}.${ext}`;
  await proofs().set(key, await file.arrayBuffer(), { metadata: { contentType: file.type } });

  const oldKey = check.squad.proofKey;
  await db.update(squads).set({ tokenFound: true, proofKey: key, foundAt: new Date() }).where(eq(squads.id, id));
  if (oldKey) await proofs().delete(oldKey).catch(() => {});

  return c.json({ ok: true, proofUrl: `/api/proof/${key}` });
});

app.get("/api/proof/:key", async (c) => {
  const key = c.req.param("key");
  if (!/^squad-\d+-[\w-]+\.(png|jpg|webp|gif)$/.test(key)) return c.notFound();
  const entry = await proofs().getWithMetadata(key, { type: "arrayBuffer" });
  if (!entry) return c.notFound();
  return new Response(entry.data, {
    headers: {
      "Content-Type": String(entry.metadata.contentType || "image/jpeg"),
      "Cache-Control": "public, max-age=31536000, immutable",
      "Access-Control-Allow-Origin": "*",
    },
  });
});

app.notFound((c) => c.json({ error: "Not found" }, 404));
app.onError((err, c) => {
  console.error(err);
  return c.json({ error: "Something went wrong on the server. Try again." }, 500);
});

export default app;
