CREATE TABLE "players" (
	"id" serial PRIMARY KEY,
	"squad_id" integer NOT NULL,
	"username" text NOT NULL,
	"username_key" text NOT NULL UNIQUE,
	"region" text NOT NULL,
	"has_mic" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "squads" (
	"id" serial PRIMARY KEY,
	"name" text,
	"region" text NOT NULL,
	"crew_code" text NOT NULL,
	"token_found" boolean DEFAULT false NOT NULL,
	"proof_key" text,
	"found_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "players_squad_idx" ON "players" ("squad_id");--> statement-breakpoint
ALTER TABLE "players" ADD CONSTRAINT "players_squad_id_squads_id_fkey" FOREIGN KEY ("squad_id") REFERENCES "squads"("id") ON DELETE CASCADE;