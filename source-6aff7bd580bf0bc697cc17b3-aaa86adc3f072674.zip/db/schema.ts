import { pgTable, serial, text, timestamp, integer, boolean, index } from "drizzle-orm/pg-core";

export const squads = pgTable("squads", {
  id: serial().primaryKey(),
  name: text("name"),
  region: text("region").notNull(),
  crewCode: text("crew_code").notNull(),
  tokenFound: boolean("token_found").notNull().default(false),
  proofKey: text("proof_key"),
  foundAt: timestamp("found_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const players = pgTable(
  "players",
  {
    id: serial().primaryKey(),
    squadId: integer("squad_id").notNull().references(() => squads.id, { onDelete: "cascade" }),
    username: text("username").notNull(),
    usernameKey: text("username_key").notNull().unique(),
    region: text("region").notNull(),
    hasMic: boolean("has_mic").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("players_squad_idx").on(t.squadId)],
);
